================================================================================
EE1004_Group14_CargoShipmentTracker_JavaGUI-LaTeX_Report
================================================================================

This is a complete, self-contained LaTeX project for Overleaf.

HOW TO USE ON OVERLEAF:
1. Download this entire folder as a ZIP.
2. On Overleaf: New Project → Upload Project → select the ZIP.
3. The main file is main.tex. It should compile with pdfLaTeX (two passes recommended for TOC).

INCLUDED:
- main.tex          : Full GUI-focused report with advanced styling
- images/           : GUI-Architecture.png and CargoShipmentTracker-ClassDiagram.png
- GUI-Chapter-for-Report.tex (optional supplementary chapter)

The report reuses the professional preamble, listings style, headers, and IEEE-style formatting from the original high-quality template you provided, while being completely restructured around the modern Java Swing GUI deliverable.

Group members, contributions (with GUI roles highlighted), diagrams, and key code listings are all included.

For any questions or further customization, contact the group lead.

================================================================================